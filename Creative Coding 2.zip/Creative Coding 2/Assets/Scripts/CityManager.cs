﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GRIDCITY
{
    public enum blockType { Block, Arches, Columns, Dishpivot, DomeWithBase, HalfDome, SlitDome, Slope, Tile, Stairs};

	public class CityManager : MonoBehaviour
    {

        #region Fields
        private static CityManager _instance;
        public Mesh[] meshArray;
        public Material[] materialArray;
        public Transform buildingPrefab;
        public BuildingProfile[] profileArray;

        public static CityManager Instance
        {
            get
            {
                return _instance;
            }
        }
        #endregion

        #region Properties	
        #endregion

        #region Methods
        #region Unity Methods

        // Use this for internal initialization
        void Awake () {
            if (_instance == null)
            {
                _instance = this;
            }

            else
            {
                Destroy(gameObject);
                Debug.LogError("Multiple CityManager instances in Scene. Destroying clone!");
            };
        }
		
		// Use this for external initialization
		void Start () {


            for (float i = 0; i < 55; i += 3f)
            {
                for (float j = 0; j < 35; j += 6f)
                {
                    for (float h = 1.5f; h < 25; h+=5)
                    {
                        {
                           // int random = Random.Range(2, profileArray.Length);
                            Instantiate(buildingPrefab, new Vector3(i, h, j), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[4]);
                        }
                    }
                }
            }
           
            //Stairs
            for (float s = -5; s < 55; s += 1) {
                Instantiate(buildingPrefab, new Vector3(s , 1, 40), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[0]);

            }

            //Ground
            for (float g = -5f; g < 56; g += 1)
            {
                for (float x = -4.5f; x < 40; x += 1) {

                    Instantiate(buildingPrefab, new Vector3(g, 0, x), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[1]);

                }
                   

            }

            //Exterior Walls

            for (float w = -5.5f; w < 56; w += 1)
               
                
                    {

                        Instantiate(buildingPrefab, new Vector3(w, 0, -5), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[2]);
                        Instantiate(buildingPrefab, new Vector3(-5, 0, w), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[2]);
                Instantiate(buildingPrefab, new Vector3(w, 0, 56), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[2]);

            }
               
            for (float y = -5.5f; y < 56; y ++)
            {
                Instantiate(buildingPrefab, new Vector3(56, 0, y), Quaternion.identity).GetComponent<DeluxeTowerBlock>().SetProfile(profileArray[2]);

            }
        }
		
		// Update is called once per frame
		void Update () {
			
		}

		#endregion
	#endregion
		
	}
}
